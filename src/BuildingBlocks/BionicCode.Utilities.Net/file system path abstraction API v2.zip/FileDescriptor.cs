﻿namespace BionicCode.Utilities.Net;

using System.Diagnostics;
using SystemIoPath = System.IO.Path;

[DebuggerDisplay("FileName = {Name}, Location = {Location}, OriginalFullPath = {OriginalFullPath}, OriginalName = {OriginalName}, IsRelative = {IsRelative}")]
public abstract class FileDescriptor : IEquatable<FileDescriptor>
{
    private readonly WriteOnce<FileExtension> _extension;
    private readonly WriteOnce<string> _name;
    private readonly WriteOnce<string> _nameWithoutExtension;
    private readonly WriteOnce<int> _hashCodeCache;

    protected FileDescriptor(FileDescriptorKind kind)
    {
        ArgumentExceptionAdvanced.ThrowIfEnumIsNotDefined<FileDescriptorKind>(kind);

        _hashCodeCache = new WriteOnce<int>();
        _extension = new WriteOnce<FileExtension>();
        _name = new WriteOnce<string>();
        _nameWithoutExtension = new WriteOnce<string>();

        Kind = kind;
    }

    protected abstract FileExtension GetFileExtension();
    protected abstract string GetName();
    protected abstract string GetNameWithoutExtension();

    public bool Equals(FileDescriptor? other)
    {
        if (other is null)
        {
            return false;
        }

        if (ReferenceEquals(this, other))
        {
            return true;
        }

        return Kind == other.Kind && Comparer.Equals(this, other);
    }

    public override int GetHashCode()
    {
        if (!_hashCodeCache.IsSet)
        {
            int hashCode = HashCode.Combine(Kind, Comparer.GetHashCode(this));
            _hashCodeCache.SetValue(hashCode);
        }

        return _hashCodeCache;
    }

    public override string? ToString() => Extension != default
        ? $"{Name}{Extension}"
        : Name;

    public override bool Equals(object? obj) => obj is FileDescriptor other && Equals(other);

    protected abstract EqualityComparer<FileDescriptor> Comparer { get; }
    public FileDescriptorKind Kind { get; }

    /// <summary>
    /// Gets the file extension associated with the file.
    /// </summary>
    public FileExtension Extension
    {
        get
        {
            if (!_extension.IsSet)
            {
                FileExtension extension = GetFileExtension();
                if (extension == default)
                {
                    extension = FileExtension.Empty;
                }

                _extension.SetValue(extension);
            }

            return _extension;

        }
    }

    /// <summary>
    /// Gets the file name.
    /// </summary>
    /// <remarks>Set <see cref="OriginalName"/> to preserve the original file name and use <see cref="Name"/> for the current file name. 
    /// This can be useful if you need to provide renaming related information where <see cref="OriginalName"/> is the old name and <see cref="Name"/> is the new name.</remarks>
    public string Name
    {
        get
        {
            if (!_name.IsSet)
            {
                string name = GetName() ?? string.Empty;
                _name.SetValue(name);
            }

            return _name;
        }
    }

    public string NameWithoutExtension
    {
        get
        {
            if (!_nameWithoutExtension.IsSet)
            {
                string nameWithoutExtension = SystemIoPath.GetFileNameWithoutExtension(Name) ?? string.Empty;
                _nameWithoutExtension.SetValue(nameWithoutExtension);
            }

            return _nameWithoutExtension;
        }
    }

    public static bool operator ==(FileDescriptor? left, FileDescriptor? right) => left?.Equals(right) ?? (right is null);
    public static bool operator !=(FileDescriptor? left, FileDescriptor? right) => !(left == right);
    public static implicit operator string(FileDescriptor fileDescriptor) => fileDescriptor?.ToString() ?? string.Empty;
}
